create view event_stats(event_id, title, participant_count, total_revenue) as
SELECT e.id          AS event_id,
       e.title,
       count(t.id)   AS participant_count,
       sum(p.amount) AS total_revenue
FROM events e
         LEFT JOIN tickets t ON e.id = t.event_id
         LEFT JOIN payments p ON t.id = p.ticket_id
GROUP BY e.id;

alter table event_stats
    owner to postgres;


create view user_stats(user_id, name, events_created, tickets_purchased) as
SELECT u.id                 AS user_id,
       u.name,
       count(DISTINCT e.id) AS events_created,
       count(DISTINCT t.id) AS tickets_purchased
FROM users u
         LEFT JOIN events e ON u.id = e.organizer_id
         LEFT JOIN tickets t ON u.id = t.participant_id
GROUP BY u.id;

alter table user_stats
    owner to postgres;

